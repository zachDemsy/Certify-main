import React from "react";

const sizes = {
  "3xl": "text-[28px] font-bold",
  "2xl": "text-2xl font-semibold",
  xl: "text-[22px] font-semibold",
  "4xl": "text-[32px] font-semibold",
  s: "text-sm font-semibold",
  md: "text-base font-semibold",
  xs: "text-xs font-semibold",
  lg: "text-lg font-bold",
};

const Heading = ({ children, className = "", size = "xs", as, ...restProps }) => {
  const Component = as || "h6";

  return (
    <Component className={`text-blue_gray-900_66 font-inter ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { Heading };
