import { Img } from "./Img";
import { Text } from "./Text";
import { Heading } from "./Heading";
import { Input } from "./Input";
import { Button } from "./Button";
import { Slider } from "./Slider";
export { Img, Text, Heading, Input, Button, Slider };
