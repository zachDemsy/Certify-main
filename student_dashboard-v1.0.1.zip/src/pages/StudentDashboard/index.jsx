import React from "react";
import { Helmet } from "react-helmet";
import { CloseSVG } from "../../assets/images";
import { Text, Heading, Button, Img, Slider, Input } from "../../components";
import { MenuItem, Menu, Sidebar } from "react-pro-sidebar";

export default function StudentDashboardPage() {
  const [sliderState, setSliderState] = React.useState(0);
  const sliderRef = React.useRef(null);
  const [searchBarValue, setSearchBarValue] = React.useState("");
  const [collapsed, setCollapsed] = React.useState(false);

  return (
    <>
      <Helmet>
        <title>Student_Dashboard</title>
        <meta name="description" content="Web site created using create-react-app" />
      </Helmet>
      <div className="flex flex-row justify-end w-full pt-[17px] bg-gray-900_01 shadow-xs">
        <div className="flex flex-row justify-start items-start w-[99%] gap-[3px]">
          <Sidebar
            width="185px !important"
            collapsedWidth="80px !important"
            collapsed={collapsed}
            onClick={() => {
              setCollapsed(!collapsed);
            }}
            className="h-screen mt-4 top-0 !sticky overflow-auto"
          >
            <div className="flex flex-row justify-start items-center w-4/5 ml-[5px] mr-[31px] gap-[13px]">
              <Img src="images/img_icon.svg" alt="icon_one" className="h-9 w-9 mb-px" />
              <Heading size="3xl" as="h3" className="!text-white-A700">
                Certify
              </Heading>
            </div>
            <Menu
              menuItemStyles={{
                button: {
                  padding: "12px 12px 12px 14px",
                  gap: "18px",
                  color: "#ffffff99",
                  fontWeight: 400,
                  fontSize: "16px",
                  borderColor: "transparent",
                  borderWidth: "0.6px",
                  borderStyle: "dashed",
                  borderRadius: "8px",
                  [`&:hover, &.ps-active`]: {
                    color: "#ffffffb2",
                    fontWeight: "500 !important",
                    borderColor: "#ffffff66",
                    backgroundColor: "#e1e7ff0f !important",
                  },
                },
              }}
              className="flex flex-col items-center justify-start w-full mt-[156px]"
            >
              <div className="flex flex-col items-center justify-start w-[98%]">
                <MenuItem icon={<Img src="images/img_icon_color.svg" alt="iconcolor_one" className="h-6 w-6" />}>
                  Dashboard
                </MenuItem>
                <MenuItem icon={<Img src="images/img_rings_909.svg" alt="rings909_one" className="h-6" />}>
                  Requests
                </MenuItem>
                <MenuItem icon={<Img src="images/img_diploma.svg" alt="diploma_one" className="h-6" />}>
                  Certificates
                </MenuItem>
              </div>
              <div className="h-px w-full mt-11 z-[1] bg-white-A700_33 rounded-[1px]" />
              <div className="flex flex-col items-center justify-start w-[98%] mt-[-1px]">
                <MenuItem icon={<Img src="images/img_layer_x0020_1.svg" alt="layerx0020one" className="h-6" />}>
                  Academics
                </MenuItem>
                <MenuItem
                  icon={<Img src="images/img_icon_color_white_a700.svg" alt="iconcolor_three" className="h-6" />}
                >
                  New Request
                </MenuItem>
              </div>
              <div className="flex flex-row justify-center w-[98%] mt-[198px]">
                <MenuItem icon={<Img src="images/img_11878337631552644365.svg" alt="image" className="h-6 w-6" />}>
                  Settings
                </MenuItem>
              </div>
            </Menu>
          </Sidebar>
          <div className="flex flex-col items-end justify-start w-[86%] gap-[17px]">
            <header className="flex flex-row justify-between items-center w-full mr-3">
              <Input
                name="search"
                placeholder="Search certificates or requests"
                value={searchBarValue}
                onChange={(e) => setSearchBarValue(e)}
                prefix={<Img src="images/img_searchicon.svg" alt="search_icon" className="cursor-pointer" />}
                suffix={
                  searchBarValue?.length > 0 ? (
                    <CloseSVG onClick={() => setSearchBarValue("")} height={18} width={19} fillColor="#ffffffff" />
                  ) : null
                }
                className="flex items-center justify-center w-[33%] h-12 pl-4 pr-[35px] gap-4 text-white-A700_99 text-sm border-blue_gray-300_19 border border-solid bg-blue_gray-300_28 rounded-[24px]"
              />
              <div className="flex flex-row justify-start items-center w-[36%] gap-5">
                <Button className="flex items-center justify-center h-12 w-12 bg-blue_gray-300_01 rounded-[50%]">
                  <Img src="images/img_icon_blue_gray_900.svg" />
                </Button>
                <div className="flex flex-row justify-start w-[81%]">
                  <div className="flex flex-row justify-center items-center w-full p-1 bg-blue_gray-300_01 rounded-[28px]">
                    <Img
                      src="images/img_pexels_nitin_khajotia_1486064.png"
                      alt="pexelsnitin_one"
                      className="h-12 w-12 ml-0.5 rounded-[50%]"
                    />
                    <div className="flex flex-col items-start justify-start w-[43%] ml-[9px] gap-0.5">
                      <Heading size="md" as="h6" className="ml-px !text-blue_gray-900_01">
                        Jhon Doe
                      </Heading>
                      <Text size="s" as="p" className="!text-gray-700">
                        jhondoe@gmail.com
                      </Text>
                    </div>
                    <Button className="flex items-center justify-center h-12 w-12 ml-[47px] mr-0.5 bg-blue_gray-800_54 rounded-[50%]">
                      <Img src="images/img_logout.svg" />
                    </Button>
                  </div>
                </div>
              </div>
            </header>
            <div className="flex flex-row justify-end w-full">
              <div className="flex flex-row justify-end items-start w-full">
                <Button className="flex items-center justify-center h-9 w-9 mt-11 z-[1] border-gray-900 border-[3px] border-solid bg-blue_gray-300_01 rounded-[50%]">
                  <Img src="images/img_toggle_menu.svg" />
                </Button>
                <div className="flex flex-row justify-end w-[99%] ml-[-18px] p-[38px] rounded-tl-[33px] rounded-bl-[33px] bg-blue_gray-300">
                  <div className="flex flex-row justify-start items-start w-full mt-[5px] mb-[88px] gap-[42px]">
                    <div className="flex flex-col items-center justify-start w-[61%]">
                      <div className="flex flex-row w-full gap-6">
                        <div className="flex flex-col items-center justify-start w-[31%]">
                          <div className="flex flex-col items-end justify-center w-full p-2.5 border-gray-900_33 border border-solid bg-blue_gray-200_a8 rounded-[24px]">
                            <div className="flex flex-col items-start justify-start w-[92%] mt-2 mb-[5px] gap-[15px]">
                              <div className="flex flex-row justify-between items-start w-full">
                                <Img
                                  src="images/img_icon_blue_gray_700.svg"
                                  alt="image"
                                  className="h-[55px] w-[55px]"
                                />
                                <Img src="images/img_menu.svg" alt="menu_one" className="h-6 w-6 mt-1" />
                              </div>
                              <Heading size="4xl" as="h1" className="ml-0.5 !text-blue_gray-900">
                                20
                              </Heading>
                              <Text as="p" className="w-[88%] ml-0.5 !text-gray-700">
                                Total number of certificates
                              </Text>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col items-center justify-start w-[31%]">
                          <div className="flex flex-col items-end justify-center w-full p-2.5 border-gray-900_33 border border-solid bg-blue_gray-200_a8 rounded-[24px]">
                            <div className="flex flex-col items-start justify-start w-[91%] mt-0.5 mb-[5px] gap-[21px]">
                              <div className="flex flex-row justify-between items-start w-full">
                                <Img
                                  src="images/img_rings_909_blue_gray_700.svg"
                                  alt="rings909_one"
                                  className="h-[46px]"
                                />
                                <Img src="images/img_menu.svg" alt="menu_one" className="h-6 w-6 mt-[9px]" />
                              </div>
                              <Heading size="4xl" as="h2" className="!text-blue_gray-900">
                                26
                              </Heading>
                              <Text as="p" className="w-[89%] !text-gray-700">
                                Total number of Requests
                              </Text>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col items-center justify-start w-[31%]">
                          <div className="flex flex-col items-center justify-start w-full p-1 border-gray-900_33 border border-solid bg-blue_gray-200_a8 rounded-[24px]">
                            <div className="flex flex-col items-center justify-start w-[87%] mb-[11px] gap-[19px]">
                              <div className="flex flex-row justify-between items-center w-full">
                                <Img src="images/img_icon_black_900.svg" alt="icon_one" className="h-[60px]" />
                                <Img src="images/img_menu.svg" alt="menu_one" className="h-6 w-6" />
                              </div>
                              <Heading size="4xl" as="h3" className="!text-blue_gray-900">
                                4
                              </Heading>
                              <Text as="p" className="w-[90%] !text-gray-700">
                                Total number of active requests
                              </Text>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-row justify-between items-center w-[97%] mt-[60px]">
                        <Heading size="2xl" as="h4" className="mt-px !text-blue_gray-900">
                          Recently Added Certificates
                        </Heading>
                        <Img src="images/img_btn.svg" alt="btn_one" className="h-7" />
                      </div>
                      <Slider
                        autoPlay
                        autoPlayInterval={2000}
                        responsive={{ 0: { items: 1 }, 550: { items: 1 }, 1050: { items: 2 } }}
                        disableDotsControls
                        activeIndex={sliderState}
                        onSlideChanged={(e) => {
                          setSliderState(e?.item);
                        }}
                        ref={sliderRef}
                        className="w-full mt-[30px]"
                        items={[...Array(6)].map(() => (
                          <React.Fragment key={Math.random()}>
                            <div className="flex flex-row justify-center mx-2.5">
                              <div className="flex flex-row justify-start w-full p-[13px] border-gray-900_33 border border-solid bg-blue_gray-200_a8 rounded-[24px]">
                                <div className="flex flex-col items-center justify-start w-[86%] mt-[5px] ml-2.5 gap-4">
                                  <div className="flex flex-row justify-center w-full">
                                    <div className="flex flex-col items-start justify-start w-full">
                                      <Heading size="xl" as="h5" className="!text-blue_gray-900">
                                        Core JAVA
                                      </Heading>
                                      <Heading as="h6" className="mt-[7px]">
                                        From{" "}
                                      </Heading>
                                      <Text as="p" className="mt-0.5 !text-gray-700_01">
                                        The programming institution
                                      </Text>
                                      <div className="flex flex-row justify-between items-center w-full mt-1.5">
                                        <div className="flex flex-col items-start justify-start gap-px">
                                          <Heading as="p">Start Date</Heading>
                                          <Text as="p" className="!text-gray-700_01">
                                            16-09-2023
                                          </Text>
                                        </div>
                                        <div className="flex flex-col items-start justify-start gap-px">
                                          <Heading as="p">End Date</Heading>
                                          <Text as="p" className="!text-gray-700_01">
                                            22-01-2024
                                          </Text>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="flex flex-row justify-center items-center w-full">
                                    <Img src="images/img_14585071916311831954127.svg" alt="image" className="h-6 w-6" />
                                    <Heading size="lg" as="h6" className="ml-1.5 !text-gray-900_3f">
                                      Certify
                                    </Heading>
                                    <Button className="flex items-center justify-center h-8 w-8 ml-[49px] bg-gray-900_28 rounded-[50%]">
                                      <Img src="images/img_group_33.svg" />
                                    </Button>
                                    <Button className="flex items-center justify-center h-8 w-8 ml-3 bg-gray-900_28 rounded-[50%]">
                                      <Img src="images/img_group_34.svg" />
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </React.Fragment>
                        ))}
                      />
                    </div>
                    <div className="flex flex-col items-center justify-start w-[36%]">
                      <div className="flex flex-col items-center justify-start w-full p-[26px] bg-gray-900_f2 rounded-[32px]">
                        <div className="flex flex-col items-center justify-start w-[99%] mb-[18px]">
                          <div className="flex flex-col items-start justify-start w-full gap-3.5">
                            <Heading size="2xl" as="h4" className="ml-0.5 !text-indigo-50">
                              Recent Requests
                            </Heading>
                            <div className="flex flex-col w-full gap-3">
                              <div className="flex flex-row justify-start items-center w-full gap-[19px] p-[11px] bg-blue_gray-300_01 rounded-[16px]">
                                <Button className="flex items-center justify-center h-[50px] w-[50px] ml-[3px] bg-deep_orange-A100_8c rounded-[50%]">
                                  <Img src="images/img_8673636701586788045.svg" />
                                </Button>
                                <div className="flex flex-row justify-start w-[61%]">
                                  <div className="flex flex-row justify-start w-full">
                                    <div className="flex flex-col items-start justify-start w-full">
                                      <Heading size="s" as="p" className="!text-gray-900_f2">
                                        Advanced Python 3
                                      </Heading>
                                      <Text size="s" as="p" className="mt-px !text-blue_gray-700_01">
                                        The programming institution
                                      </Text>
                                      <div className="flex flex-row justify-start mt-1.5 gap-1.5">
                                        <Text
                                          size="xs"
                                          as="p"
                                          className="flex justify-center items-center w-16 h-4 px-[11px] py-[3px] bg-indigo-800_28 rounded-lg"
                                        >
                                          In progress
                                        </Text>
                                        <Text
                                          size="xs"
                                          as="p"
                                          className="flex justify-center items-center w-16 h-4 px-2.5 py-[3px] bg-indigo-800_14 rounded-lg"
                                        >
                                          16-01-2024
                                        </Text>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="flex flex-row justify-start items-center w-full gap-[19px] p-2.5 bg-blue_gray-300_01 rounded-[16px]">
                                <Button className="flex items-center justify-center h-[50px] w-[50px] ml-1 bg-green-A200_8c rounded-[50%]">
                                  <Img src="images/img_6352244251642233797.svg" />
                                </Button>
                                <div className="flex flex-row justify-start w-[61%]">
                                  <div className="flex flex-row justify-start w-full">
                                    <div className="flex flex-col items-start justify-start w-full gap-1">
                                      <Heading size="s" as="p" className="!text-gray-900_f2">
                                        Core JAVA
                                      </Heading>
                                      <Text size="s" as="p" className="!text-blue_gray-700_01">
                                        The programming institution
                                      </Text>
                                      <div className="flex flex-row justify-start gap-1.5">
                                        <Text
                                          size="xs"
                                          as="p"
                                          className="flex justify-center items-center w-16 h-4 px-[11px] py-[3px] bg-indigo-800_28 rounded-lg"
                                        >
                                          Successful
                                        </Text>
                                        <Text
                                          size="xs"
                                          as="p"
                                          className="flex justify-center items-center w-16 h-4 px-2.5 py-[3px] bg-indigo-800_14 rounded-lg"
                                        >
                                          16-01-2024
                                        </Text>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="flex flex-row justify-start items-center w-full gap-[19px] p-2.5 bg-blue_gray-300_01 rounded-[16px]">
                                <Button className="flex items-center justify-center h-[50px] w-[50px] ml-1 bg-red-300_8c rounded-[50%]">
                                  <Img src="images/img_6352244251642233797_gray_900.svg" />
                                </Button>
                                <div className="flex flex-row justify-start w-[61%]">
                                  <div className="flex flex-row justify-start w-full">
                                    <div className="flex flex-col items-start justify-start w-full gap-1">
                                      <Heading size="s" as="p" className="!text-gray-900_f2">
                                        Advanced PHP
                                      </Heading>
                                      <Text size="s" as="p" className="!text-blue_gray-700_01">
                                        The programming institution
                                      </Text>
                                      <div className="flex flex-row justify-start gap-1.5">
                                        <Text
                                          size="xs"
                                          as="p"
                                          className="flex justify-center items-center w-16 h-4 px-[21px] py-[3px] bg-indigo-800_28 rounded-lg"
                                        >
                                          Failed
                                        </Text>
                                        <Text
                                          size="xs"
                                          as="p"
                                          className="flex justify-center items-center w-16 h-4 px-2.5 py-[3px] bg-indigo-800_14 rounded-lg"
                                        >
                                          16-01-2024
                                        </Text>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
